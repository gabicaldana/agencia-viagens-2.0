package agencia.view;

import agencia.controller.DadosController;
import agencia.model.*;
import javax.swing.*;
import javax.swing.border.*;
import javax.swing.table.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class PedidosFrame extends JFrame {
    private final DadosController controller;
    private JTable table;
    private DefaultTableModel model;
    private List<Pedido> pedidos;

    public PedidosFrame(DadosController controller) {
        this.controller = controller;
        initComponents();
    }

    private void initComponents() {
        setTitle("Pedidos");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        String[] colunas = {"ID", "Cliente", "Data", "Pacotes", "Serviços", "Total (R$)"};
        model = new DefaultTableModel(colunas, 0) {
            @Override public boolean isCellEditable(int row, int column) { return false; }
        };
        table = new JTable(model);
        configurarTabela();
        mainPanel.add(new JScrollPane(table), BorderLayout.CENTER);

        JPanel botoesPanel = new JPanel(new FlowLayout(FlowLayout.RIGHT, 10, 0));
        JButton btnNovo = new JButton("Novo Pedido");
        JButton btnEditar = new JButton("Editar");
        JButton btnDetalhes = new JButton("Ver Detalhes");
        JButton btnExcluir = new JButton("Excluir");
        JButton btnAtualizar = new JButton("Atualizar");
        
        botoesPanel.add(btnNovo);
        botoesPanel.add(btnEditar);
        botoesPanel.add(btnDetalhes);
        botoesPanel.add(btnExcluir);
        botoesPanel.add(btnAtualizar);
        
        mainPanel.add(botoesPanel, BorderLayout.SOUTH);

        btnNovo.addActionListener(e -> criarPedidoDialog(null));
        btnEditar.addActionListener(e -> {
            int linha = table.getSelectedRow();
            if (linha >= 0) {
                criarPedidoDialog(pedidos.get(table.convertRowIndexToModel(linha)));
            } else {
                JOptionPane.showMessageDialog(this, 
                    "Selecione um pedido para editar", 
                    "Aviso", JOptionPane.WARNING_MESSAGE);
            }
        });
        btnDetalhes.addActionListener(e -> verDetalhesPedido());
        btnExcluir.addActionListener(e -> excluirPedido());
        btnAtualizar.addActionListener(e -> atualizarTabela());

        setContentPane(mainPanel);
        pack();
        setLocationRelativeTo(null);
        atualizarTabela();
    }

    private void configurarTabela() {
        table.setFont(new Font("Segoe UI", Font.PLAIN, 14));
        table.setRowHeight(28);
        table.getTableHeader().setFont(new Font("Segoe UI", Font.BOLD, 14));
        table.setSelectionMode(ListSelectionModel.SINGLE_SELECTION);
    }

    private void atualizarTabela() {
        this.pedidos = controller.carregarPedidos();
        model.setRowCount(0);
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy HH:mm");
        
        for (Pedido p : this.pedidos) {
            model.addRow(new Object[]{
                p.getId(), 
                p.getCliente().getNome(), 
                sdf.format(p.getData()), 
                p.getPacotes().size(), 
                p.getServicos().size(), 
                String.format("%.2f", p.getTotal())
            });
        }
    }

    private void verDetalhesPedido() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Pedido pedido = pedidos.get(table.convertRowIndexToModel(selectedRow));
            JTextArea textArea = new JTextArea(pedido.getResumo());
            textArea.setFont(new Font("Monospaced", Font.PLAIN, 12));
            textArea.setEditable(false);
            textArea.setMargin(new Insets(10, 10, 10, 10));
            
            JScrollPane scrollPane = new JScrollPane(textArea);
            scrollPane.setPreferredSize(new Dimension(600, 400));
            
            JOptionPane.showMessageDialog(this, scrollPane, 
                "Detalhes do Pedido #" + pedido.getId(), 
                JOptionPane.INFORMATION_MESSAGE);
        } else {
            JOptionPane.showMessageDialog(this, 
                "Selecione um pedido para ver os detalhes.", 
                "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void excluirPedido() {
        int selectedRow = table.getSelectedRow();
        if (selectedRow != -1) {
            Pedido pedido = pedidos.get(table.convertRowIndexToModel(selectedRow));
            int confirm = JOptionPane.showConfirmDialog(this, 
                "Excluir o pedido do cliente '" + pedido.getCliente().getNome() + "'?", 
                "Confirmação", JOptionPane.YES_NO_OPTION);
                
            if (confirm == JOptionPane.YES_OPTION) {
                controller.excluirPedido(pedido.getId());
                atualizarTabela();
            }
        } else {
            JOptionPane.showMessageDialog(this, 
                "Selecione um pedido para excluir.", 
                "Aviso", JOptionPane.WARNING_MESSAGE);
        }
    }

    private void criarPedidoDialog(Pedido pedidoExistente) {
        boolean isEdit = pedidoExistente != null;
        String titulo = isEdit ? "Editar Pedido #" + pedidoExistente.getId() : "Novo Pedido";

        List<Cliente> clientes = controller.carregarClientes();
        List<PacoteViagem> pacotes = controller.carregarPacotes();
        List<ServicoAdicional> servicos = controller.carregarServicos();

        if (clientes.isEmpty() || pacotes.isEmpty()) {
            JOptionPane.showMessageDialog(this,
                "É necessário cadastrar clientes e pacotes antes de criar um pedido.",
                "Erro", JOptionPane.ERROR_MESSAGE);
            return;
        }

        JDialog dialog = new JDialog(this, titulo, true);
        dialog.setSize(700, 600);
        dialog.setLayout(new BorderLayout(10, 10));
        dialog.setLocationRelativeTo(this);

        JPanel contentPanel = new JPanel();
        contentPanel.setLayout(new BoxLayout(contentPanel, BoxLayout.Y_AXIS));
        contentPanel.setBorder(new EmptyBorder(15, 15, 15, 15));

        // 1. Seleção do Cliente
        JComboBox<Cliente> clienteCombo = new JComboBox<>(clientes.toArray(new Cliente[0]));
        if (isEdit) {
            clienteCombo.setSelectedItem(pedidoExistente.getCliente());
            clienteCombo.setEnabled(false);
        }

        JPanel clientePanel = new JPanel(new BorderLayout(0, 5));
        clientePanel.setBorder(new TitledBorder("1. Cliente"));
        clientePanel.add(clienteCombo, BorderLayout.CENTER);

        // 2. Seleção de Pacotes
        DefaultListModel<PacoteViagem> modeloPacotes = new DefaultListModel<>();
        pacotes.forEach(modeloPacotes::addElement);
        
        JList<PacoteViagem> listaPacotes = new JList<>(modeloPacotes);
        listaPacotes.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        
        if (isEdit) {
            listaPacotes.setSelectedIndices(obterIndicesSelecionados(pacotes, pedidoExistente.getPacotes()));
        }

        JPanel pacotesPanel = new JPanel(new BorderLayout(0, 5));
        pacotesPanel.setBorder(new TitledBorder("2. Pacotes (selecione pelo menos um)"));
        pacotesPanel.add(new JScrollPane(listaPacotes), BorderLayout.CENTER);

        // 3. Seleção de Serviços Adicionais
        DefaultListModel<ServicoAdicional> modeloServicos = new DefaultListModel<>();
        servicos.forEach(modeloServicos::addElement);
        
        JList<ServicoAdicional> listaServicos = new JList<>(modeloServicos);
        listaServicos.setSelectionMode(ListSelectionModel.MULTIPLE_INTERVAL_SELECTION);
        
        if (isEdit) {
            listaServicos.setSelectedIndices(obterIndicesSelecionados(servicos, pedidoExistente.getServicos()));
        }

        JPanel servicosPanel = new JPanel(new BorderLayout(0, 5));
        servicosPanel.setBorder(new TitledBorder("3. Serviços Adicionais (opcional)"));
        servicosPanel.add(new JScrollPane(listaServicos), BorderLayout.CENTER);

        contentPanel.add(clientePanel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        contentPanel.add(pacotesPanel);
        contentPanel.add(Box.createRigidArea(new Dimension(0, 10)));
        contentPanel.add(servicosPanel);

        JButton btnConfirmar = new JButton(isEdit ? "Atualizar Pedido" : "Criar Pedido");
        btnConfirmar.addActionListener(e -> {
            List<PacoteViagem> pacotesSelecionados = listaPacotes.getSelectedValuesList();
            
            if (pacotesSelecionados.isEmpty()) {
                JOptionPane.showMessageDialog(dialog,
                    "Selecione pelo menos um pacote de viagem!",
                    "Atenção", JOptionPane.WARNING_MESSAGE);
                return;
            }

            Cliente cliente = (Cliente) clienteCombo.getSelectedItem();
            Pedido pedido = isEdit ? pedidoExistente : new Pedido(0, cliente, new Date());
            
            pedido.getPacotes().clear();
            pedido.getServicos().clear();
            
            pacotesSelecionados.forEach(pedido::adicionarPacote);
            listaServicos.getSelectedValuesList().forEach(pedido::adicionarServico);

            try {
                if (isEdit) {
                    controller.atualizarPedido(pedido);
                } else {
                    controller.salvarPedido(pedido);
                }
                
                atualizarTabela();
                JOptionPane.showMessageDialog(dialog,
                    "Pedido " + (isEdit ? "atualizado" : "criado") + " com sucesso!\n" +
                    "Total: R$ " + String.format("%.2f", pedido.getTotal()),
                    "Sucesso", JOptionPane.INFORMATION_MESSAGE);
                dialog.dispose();
            } catch (Exception ex) {
                JOptionPane.showMessageDialog(dialog,
                    "Erro ao " + (isEdit ? "atualizar" : "criar") + " pedido: " + ex.getMessage(),
                    "Erro", JOptionPane.ERROR_MESSAGE);
            }
        });

        JPanel panelBotoes = new JPanel(new FlowLayout(FlowLayout.RIGHT));
        panelBotoes.setBorder(new EmptyBorder(10, 0, 0, 0));
        panelBotoes.add(btnConfirmar);

        dialog.add(contentPanel, BorderLayout.CENTER);
        dialog.add(panelBotoes, BorderLayout.SOUTH);
        dialog.setVisible(true);
    }

    private int[] obterIndicesSelecionados(List<?> listaCompleta, List<?> itensSelecionados) {
        return itensSelecionados.stream()
                .mapToInt(item -> listaCompleta.indexOf(item))
                .toArray();
    }
}