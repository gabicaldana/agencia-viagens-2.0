package agencia.view;

import agencia.controller.DadosController;
import agencia.model.*;
import javax.swing.*;
import javax.swing.border.*;
import java.awt.*;
import java.text.SimpleDateFormat;
import java.util.*;
import java.util.List;

public class RelatoriosFrame extends JFrame {
    private final DadosController controller;
    private final JTextArea textArea = new JTextArea();

    public RelatoriosFrame(DadosController controller) {
        this.controller = controller;
        initComponents();
    }

    private void initComponents() {
        setTitle("Relatórios");
        setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
        
        JPanel mainPanel = new JPanel(new BorderLayout(10, 10));
        mainPanel.setBorder(new CompoundBorder(
            new EmptyBorder(15, 15, 15, 15),
            new MatteBorder(1, 1, 1, 1, new Color(0x3f51b5))
        ));
        mainPanel.setBackground(new Color(0xf5f5f5));

        // Título da janela
        JLabel titleLabel = new JLabel("Relatórios da Agência");
        titleLabel.setFont(new Font("Segoe UI", Font.BOLD, 18));
        titleLabel.setForeground(new Color(0x3f51b5));
        titleLabel.setBorder(new EmptyBorder(0, 0, 15, 0));
        titleLabel.setHorizontalAlignment(SwingConstants.CENTER);
        mainPanel.add(titleLabel, BorderLayout.NORTH);

        // Configuração da textArea
        textArea.setFont(new Font("Monospaced", Font.PLAIN, 14));
        textArea.setEditable(false);
        textArea.setMargin(new Insets(10, 10, 10, 10));
        textArea.setBackground(Color.WHITE);
        
        // Painel da área de texto com borda
        JPanel textPanel = new JPanel(new BorderLayout());
        textPanel.setBorder(new CompoundBorder(
            new MatteBorder(1, 1, 1, 1, new Color(0xe0e0e0)),
            new EmptyBorder(5, 5, 5, 5)
        ));
        textPanel.setBackground(Color.WHITE);
        textPanel.add(new JScrollPane(textArea), BorderLayout.CENTER);
        mainPanel.add(textPanel, BorderLayout.CENTER);

        // Painel de botões
        JPanel botoesPanel = new JPanel(new GridLayout(2, 3, 10, 10));
        botoesPanel.setBorder(new EmptyBorder(10, 0, 0, 0));
        botoesPanel.setBackground(new Color(0xf5f5f5));
        
        JButton btnResumo = criarBotaoEstilizado("Resumo Geral", new Color(0x2196f3));
        JButton btnVendas = criarBotaoEstilizado("Vendas por Data", new Color(0x4caf50));
        JButton btnPacotesPopulares = criarBotaoEstilizado("Pacotes Populares", new Color(0xff9800));
        JButton btnPacotesPorCliente = criarBotaoEstilizado("Pacotes por Cliente", new Color(0x9c27b0));
        JButton btnClientesPorPacote = criarBotaoEstilizado("Clientes por Pacote", new Color(0x009688));
        
        botoesPanel.add(btnResumo);
        botoesPanel.add(btnVendas);
        botoesPanel.add(btnPacotesPopulares);
        botoesPanel.add(btnPacotesPorCliente);
        botoesPanel.add(btnClientesPorPacote);
        
        mainPanel.add(botoesPanel, BorderLayout.SOUTH);

        btnResumo.addActionListener(e -> gerarResumoGeral());
        btnVendas.addActionListener(e -> gerarVendasPorData());
        btnPacotesPopulares.addActionListener(e -> gerarPacotesPopulares());
        btnPacotesPorCliente.addActionListener(e -> selecionarClienteParaRelatorio());
        btnClientesPorPacote.addActionListener(e -> selecionarPacoteParaRelatorio());

        setContentPane(mainPanel);
        pack();
        setLocationRelativeTo(null);
    }

    private JButton criarBotaoEstilizado(String texto, Color cor) {
        JButton botao = new JButton(texto);
        botao.setFont(new Font("Segoe UI", Font.BOLD, 12));
        botao.setBackground(cor);
        botao.setForeground(Color.WHITE);
        botao.setFocusPainted(false);
        return botao;
    }

    private void gerarResumoGeral() {
        List<Cliente> clientes = controller.carregarClientes();
        List<PacoteViagem> pacotes = controller.carregarPacotes();
        List<ServicoAdicional> servicos = controller.carregarServicos();
        List<Pedido> pedidos = controller.carregarPedidos();

        double faturamentoTotal = pedidos.stream().mapToDouble(Pedido::getTotal).sum();

        StringBuilder sb = new StringBuilder("=== RESUMO GERAL ===\n\n");
        sb.append(String.format("%-25s %d\n", "Total de Clientes:", clientes.size()));
        sb.append(String.format("%-25s %d\n", "Total de Pacotes:", pacotes.size()));
        sb.append(String.format("%-25s %d\n", "Total de Serviços:", servicos.size()));
        sb.append(String.format("%-25s %d\n\n", "Total de Pedidos:", pedidos.size()));
        sb.append("----------------------------------------\n");
        sb.append(String.format("%-25s R$ %.2f\n", "FATURAMENTO TOTAL:", faturamentoTotal));
        
        textArea.setText(sb.toString());
    }

    private void gerarVendasPorData() {
        List<Pedido> pedidos = controller.carregarPedidos();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        Map<String, Double> vendasPorData = new TreeMap<>();

        for (Pedido p : pedidos) {
            String data = sdf.format(p.getData());
            vendasPorData.put(data, vendasPorData.getOrDefault(data, 0.0) + p.getTotal());
        }
        
        StringBuilder sb = new StringBuilder("=== VENDAS POR DATA ===\n\n");
        for (Map.Entry<String, Double> entry : vendasPorData.entrySet()) {
            sb.append(String.format("%-12s R$ %.2f\n", entry.getKey() + ":", entry.getValue()));
        }

        textArea.setText(sb.toString());
    }

    private void gerarPacotesPopulares() {
        List<Pedido> pedidos = controller.carregarPedidos();
        Map<String, Integer> contagemPacotes = new HashMap<>();

        for (Pedido p : pedidos) {
            for (PacoteViagem pacote : p.getPacotes()) {
                String nomePacote = pacote.getNome();
                contagemPacotes.put(nomePacote, contagemPacotes.getOrDefault(nomePacote, 0) + 1);
            }
        }

        List<Map.Entry<String, Integer>> lista = new ArrayList<>(contagemPacotes.entrySet());
        lista.sort((a, b) -> b.getValue().compareTo(a.getValue()));

        StringBuilder sb = new StringBuilder("=== PACOTES MAIS VENDIDOS ===\n\n");
        for (Map.Entry<String, Integer> entry : lista) {
            sb.append(String.format("%-30s %d venda(s)\n", entry.getKey() + ":", entry.getValue()));
        }

        textArea.setText(sb.toString());
    }

    private void selecionarClienteParaRelatorio() {
        List<Cliente> clientes = controller.carregarClientes();
        
        if (clientes.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Não há clientes cadastrados.", 
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JComboBox<Cliente> clienteCombo = new JComboBox<>(clientes.toArray(new Cliente[0]));
        clienteCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof Cliente) {
                    setText(((Cliente) value).getNome());
                }
                return this;
            }
        });
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Selecione um cliente:"), BorderLayout.NORTH);
        panel.add(clienteCombo, BorderLayout.CENTER);
        
        int result = JOptionPane.showConfirmDialog(
            this, 
            panel, 
            "Selecionar Cliente", 
            JOptionPane.OK_CANCEL_OPTION, 
            JOptionPane.PLAIN_MESSAGE
        );
        
        if (result == JOptionPane.OK_OPTION) {
            Cliente clienteSelecionado = (Cliente) clienteCombo.getSelectedItem();
            gerarPacotesPorCliente(clienteSelecionado);
        }
    }

    private void gerarPacotesPorCliente(Cliente cliente) {
        List<Pedido> pedidos = controller.carregarPedidos();
        Set<PacoteViagem> pacotes = new HashSet<>();
        SimpleDateFormat sdf = new SimpleDateFormat("dd/MM/yyyy");
        
        for (Pedido p : pedidos) {
            if (p.getCliente().getId() == cliente.getId()) {
                pacotes.addAll(p.getPacotes());
            }
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== PACOTES CONTRATADOS POR ").append(cliente.getNome().toUpperCase()).append(" ===\n\n");
        sb.append("Cliente: ").append(cliente.getNome()).append("\n");
        sb.append("Documento: ").append(cliente.getDocumento()).append("\n");
        sb.append("Email: ").append(cliente.getEmail()).append("\n");
        sb.append("Telefone: ").append(cliente.getTelefone()).append("\n\n");
        
        if (pacotes.isEmpty()) {
            sb.append("Nenhum pacote contratado por este cliente.\n");
        } else {
            sb.append("Pacotes contratados:\n");
            for (PacoteViagem p : pacotes) {
                sb.append(" - ").append(p.getNome()).append(" (").append(p.getDestino()).append(")\n");
                sb.append("   Tipo: ").append(p.getTipo()).append("\n");
                sb.append("   Duração: ").append(p.getDuracao()).append(" dias\n");
                sb.append("   Preço: R$ ").append(String.format("%.2f", p.getPreco())).append("\n\n");
            }
        }
        
        textArea.setText(sb.toString());
    }

    private void selecionarPacoteParaRelatorio() {
        List<PacoteViagem> pacotes = controller.carregarPacotes();
        
        if (pacotes.isEmpty()) {
            JOptionPane.showMessageDialog(this, 
                "Não há pacotes cadastrados.", 
                "Aviso", JOptionPane.WARNING_MESSAGE);
            return;
        }
        
        JComboBox<PacoteViagem> pacoteCombo = new JComboBox<>(pacotes.toArray(new PacoteViagem[0]));
        pacoteCombo.setRenderer(new DefaultListCellRenderer() {
            @Override
            public Component getListCellRendererComponent(JList<?> list, Object value, int index, boolean isSelected, boolean cellHasFocus) {
                super.getListCellRendererComponent(list, value, index, isSelected, cellHasFocus);
                if (value instanceof PacoteViagem) {
                    setText(((PacoteViagem) value).getNome());
                }
                return this;
            }
        });
        
        JPanel panel = new JPanel(new BorderLayout());
        panel.add(new JLabel("Selecione um pacote:"), BorderLayout.NORTH);
        panel.add(pacoteCombo, BorderLayout.CENTER);
        
        int result = JOptionPane.showConfirmDialog(
            this, 
            panel, 
            "Selecionar Pacote", 
            JOptionPane.OK_CANCEL_OPTION, 
            JOptionPane.PLAIN_MESSAGE
        );
        
        if (result == JOptionPane.OK_OPTION) {
            PacoteViagem pacoteSelecionado = (PacoteViagem) pacoteCombo.getSelectedItem();
            gerarClientesPorPacote(pacoteSelecionado);
        }
    }

    private void gerarClientesPorPacote(PacoteViagem pacote) {
        List<Pedido> pedidos = controller.carregarPedidos();
        Set<Cliente> clientes = new HashSet<>();
        
        for (Pedido p : pedidos) {
            for (PacoteViagem pac : p.getPacotes()) {
                if (pac.getId() == pacote.getId()) {
                    clientes.add(p.getCliente());
                }
            }
        }
        
        StringBuilder sb = new StringBuilder();
        sb.append("=== CLIENTES QUE CONTRATARAM ").append(pacote.getNome().toUpperCase()).append(" ===\n\n");
        sb.append("Pacote: ").append(pacote.getNome()).append("\n");
        sb.append("Destino: ").append(pacote.getDestino()).append("\n");
        sb.append("Tipo: ").append(pacote.getTipo()).append("\n");
        sb.append("Duração: ").append(pacote.getDuracao()).append(" dias\n");
        sb.append("Preço: R$ ").append(String.format("%.2f", pacote.getPreco())).append("\n\n");
        
        if (clientes.isEmpty()) {
            sb.append("Nenhum cliente contratou este pacote.\n");
        } else {
            sb.append("Clientes que contrataram este pacote:\n");
            for (Cliente c : clientes) {
                sb.append(" - ").append(c.getNome()).append(" (").append(c.getDocumento()).append(")\n");
                sb.append("   Email: ").append(c.getEmail()).append("\n");
                sb.append("   Telefone: ").append(c.getTelefone()).append("\n\n");
            }
        }
        
        textArea.setText(sb.toString());
    }
}